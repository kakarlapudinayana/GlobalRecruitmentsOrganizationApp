package com.capgemini.contactbook.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;




public class Client {
	
	
	private static final String enquiryId = null;
	static Scanner sc = new Scanner(System.in);
		static ContactBookService contactbookService = null;
		static ContactBookServiceImpl contactbookServiceImpl = null;
		static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws Exception {
		PropertyConfigurator.configure("resources//log4j.properties");
	EnquiryBean enquirybean = null;
	String enquiryId  =null;
	
	int option =0 ;
	
	

	while (true) {

		// showing menu
		System.out.println();
		System.out.println();
		System.out.println("   Global Recruitments Organization ");
		

		System.out.println("1.Enter Enquiry details ");
		System.out.println("2.View Enquiry Details");
		System.out.println("3.Retrive Enquiry Details");
		System.out.println("0.Exit");
		
		
		System.out.println("Select an option:");
		// accepting option

		try {
			option = sc.nextInt();

			switch (option) {

			case 1:

				while (enquirybean  == null) {
					enquirybean   = populateenquirybean();
					 System.out.println(enquirybean);
				}

				try {
					contactbookService= new ContactBookServiceImpl();
					enquiryId = contactbookService.addEnquiry(enquirybean);

					System.out.println("enquiry details  has been successfully registered ");
					System.out.println("enquiry ID Is: " + enquiryId);
					

				} catch (ContactBookException contactBookException) {
					logger.error("exception occured", contactBookException);
					System.out.println("ERROR : "
							+ contactBookException.getMessage());
				} finally {
					
					contactbookService = null;
					enquirybean = null;
					enquiryId=null;
				}

				break;

			case 2:

				contactbookServiceImpl = new ContactBookServiceImpl();

				System.out.println("Enter numeric contact book id:");
				enquiryId = sc.next();

				while (true) {
					
					if (contactbookServiceImpl.isvalidEnquiryId(enquiryId)) {
						
					
						break;
					} else {
						System.err
								.println("Please enter numeric donor id only, try again");
						enquiryId = sc.next();
					}
				}

				enquirybean =getContactBookDetails(enquiryId);
						
			
				if (enquirybean != null) {
					
					
					System.out.println("First Name:"+enquirybean.getfName());
					System.out.println("Last Name:"+enquirybean.getlName());
					System.out.println("Contact No:"+enquirybean.getContactNo());
					System.out.println("Domain:"+enquirybean.getpDomain());
					System.out.println("Location:"+enquirybean.getpLocation());
				} else {
					System.err
							.println("\n There are no contact book details associated with enquiry id "
									+ enquiryId);
				}

				break;
				
			case 3:

				contactbookService = new ContactBookServiceImpl();
				try {
					List<EnquiryBean> bookList = new ArrayList<EnquiryBean>();
					bookList = contactbookService.retriveAll();

					if (bookList != null) {
						Iterator<EnquiryBean> i = bookList.iterator();
						while (i.hasNext()) {
							System.out.println(i.next());
						}
					} else {
						System.out
								.println("Nobody has added a contact book details , yet.");
					}

				}

				catch (ContactBookException e) {

					System.out.println("Error  :" + e.getMessage());
				}

				break;
				
				
			case 0:

				System.out.print("Thanks for being with us!");
				System.exit(0);
				break;
			default:
				System.out.println("Enter a valid option[0-3]");
			}// end of switch
		}

		catch (InputMismatchException e) {
			sc.nextLine();
			System.err.println("Please enter a numeric value, try again");
	}

	}// end of while
	
	

	}
	
	private static EnquiryBean getContactBookDetails(String enquiryId) {
		EnquiryBean EnquiryBean = null;
		contactbookService = new ContactBookServiceImpl();

		try {
			EnquiryBean = contactbookService.viewEnquiryDetails(enquiryId);
		} catch (ContactBookException contactException) {
			logger.error("exception occured ", contactException);
			System.out.println("ERROR : " + contactException.getMessage());
		}

		contactbookService = null;
		return EnquiryBean;
	}

	private static EnquiryBean populateenquirybean() {

		
		EnquiryBean enquirybean = new EnquiryBean();

		System.out.println("\nEnquiry Details");

		System.out.println("Enter first name: ");
		enquirybean.setfName(sc.next());
		
		System.out.println("Enter last name: ");
		enquirybean.setlName(sc.next());
		
		System.out.println("Enter contact number: ");
		enquirybean.setContactNo(sc.next());
		
		
		
		System.out.println("Enter prefered domain: ");
		enquirybean.setpDomain(sc.next());
		
		System.out.println("Enter prefered location: ");
		enquirybean.setpLocation(sc.next());
		
	
		
        contactbookServiceImpl = new ContactBookServiceImpl();
//System.out.println("After creating patient service impl object");

        try {
        	contactbookServiceImpl.isValidEnquiry(enquirybean);
			
					return enquirybean;
		} catch (ContactBookException ContactBookException) {
			logger.error("exception occured", ContactBookException);
			System.err.println("Invalid data:");
			System.err.println(ContactBookException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}
