package com.capgemini.contactbook.test;  

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;




public class ContactBookDaoTest {

    static ContactBookDaoImpl dao;
    static EnquiryBean enquirybean;

    @BeforeClass
    public static void initialize() {
        dao = new ContactBookDaoImpl();
        enquirybean = new EnquiryBean();
    }

    @Test
    public void testAddPatientDetails() throws ContactBookException {

        assertNotNull(dao.addEnquiry(enquirybean));
    }
    
    /************************************
     * Test case for addEnquiryDetails()
     * 
     ************************************/

    @Ignore
    @Test
    public void testAddPatientDetails1() throws ContactBookException {
        assertEquals(1001, dao.addEnquiry(enquirybean));
    }

    /************************************
     * Test case for addEnquiryDetails()
     * 
     ************************************/

    @Test
    public void testAddPatientDetails2() throws ContactBookException {
        
    	enquirybean.setfName("nayana");
    	enquirybean.setlName("varma");
    	enquirybean.setContactNo("1234567890");
    	enquirybean.setpDomain("java");
    	enquirybean.setpLocation("hyd");
        assertTrue("Data Inserted successfully",
                Integer.parseInt(dao.addEnquiry(enquirybean)) > 1000);

    }
}